self.__precacheManifest = [
  {
    "revision": "8bdc6e03e21dbed3ad2dd6d145d310ff",
    "url": "./static/media/writeoff.8bdc6e03.svg"
  },
  {
    "revision": "251d910f0591c00fc07e",
    "url": "./static/css/main.900f492f.chunk-rexhang.css"
  },
  {
    "revision": "3e3a7bb91c294bfbef43460b1e30641c",
    "url": "./static/media/notonline.3e3a7bb9.svg"
  },
  {
    "revision": "c1efb4981a3455e27ab7",
    "url": "./static/js/1.c1efb498.chunk-rexhang.js"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "fc9b2e18a0e21c712e227e88248882c1",
    "url": "./static/media/pointer_mouse.fc9b2e18.cur"
  },
  {
    "revision": "2592011c60739f9fbcae27b9e0fb7822",
    "url": "./static/media/medicine.2592011c.svg"
  },
  {
    "revision": "42a5b3ac0b5718e1043fa6045e6c3184",
    "url": "./static/media/medical-record.42a5b3ac.svg"
  },
  {
    "revision": "18c987e5ebf65615bc03dc39ba3a6c63",
    "url": "./static/media/style.18c987e5.svg"
  },
  {
    "revision": "c442867c076d8dc2914d67427e738eff",
    "url": "./static/media/acupuncture-point.c442867c.svg"
  },
  {
    "revision": "63623acfd9fd032afeed8b86e6dc4f72",
    "url": "./static/media/system.63623acf.svg"
  },
  {
    "revision": "251d910f0591c00fc07e",
    "url": "./static/js/main.251d910f.chunk-rexhang.js"
  },
  {
    "revision": "b1acc3ddb208ce500aa455d814bbe47e",
    "url": "./static/media/core.b1acc3dd.svg"
  },
  {
    "revision": "269b800286add35786c96067ce380bfb",
    "url": "./static/media/rainy-preloader.269b8002.svg"
  },
  {
    "revision": "fa6eb3fae460f7c3e8bb95557691f87c",
    "url": "./static/media/error-fill.fa6eb3fa.svg"
  },
  {
    "revision": "73c4a29e796e6bb45f56b50979a25f2d",
    "url": "./static/media/msg.73c4a29e.svg"
  },
  {
    "revision": "043236b6c4c5ffe6de65e9674308bdfb",
    "url": "./static/media/poweroff.043236b6.svg"
  },
  {
    "revision": "767d9b0a7eb252b945be54ada851256e",
    "url": "./static/media/welcome.767d9b0a.svg"
  },
  {
    "revision": "fcf21c10f209ab2b5288bd9448f3159c",
    "url": "./static/media/norecord.fcf21c10.svg"
  },
  {
    "revision": "a568162c2e16b799f5d56634d9e23e46",
    "url": "./static/media/ant-bg.a568162c.svg"
  },
  {
    "revision": "c1efb4981a3455e27ab7",
    "url": "./static/css/1.5dfb9ef2.chunk-rexhang.css"
  },
  {
    "revision": "74da2a8070fee4b51ac7aab771529585",
    "url": "./index.html"
  }
];